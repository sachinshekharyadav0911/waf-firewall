
console.log("[WAF] Hybrid Smart WAF starting (default: Non-Blocking)");

const STORAGE_KEYS = {
  MODE: "waf_mode_v3",           // "blocking" or "non-blocking"
  LOGS: "waf_logs_v3",
  WHITELIST: "waf_whitelist_v3"
};

const MAX_LOGS = 100;

// Default whitelist (can be edited from dashboard)
const DEFAULT_WHITELIST = [
  "mozilla.org",
  "wikipedia.org"
];

// Comprehensive suspicious keywords + patterns
const suspiciousKeywords = [
  "hack","hacked","hackers","crack","cracked","cracker","exploit","exploits","payload","payloads",
  "malware","ransomware","phish","phishing","trojan","virus","worm","backdoor","backdoors",
  "sqlmap","sqlinject","sql","injection","injections","xss","xssed","xssattack","xsspayload",
  "union","select","insert","update","delete","drop","exec","fetch","declare","cast","convert",
  "information_schema","table_name","xp_cmdshell","cmd","bash","powershell","wget","curl",
  "chmod","sudo","shell_exec","os.system","subprocess","system(","document.cookie","onerror=",
  "<script","alert(","prompt(","iframe","src=","base64","0day","zeroday","zero-day","overflow",
  "buffer overflow","root","admin","password","passwd","token","keylogger","stealer","sniffer",
  "nmap","scan","sqlmap","adminer","phpinfo","/etc/passwd","passwd","config.php","wp-login.php",
  "wp-admin","phpmyadmin","adminer.php","backdoor","webshell","shell.php","cmd.php","eval(",
  "assert(","passthru(","popen(","proc_open(","system(","exec(","shell_exec("
];

// Regex patterns for stronger detection
const suspiciousPatterns = [
  /<script.*?>.*?<\/script>/i,
  /onerror\s*=/i,
  /union\s+select/i,
  /drop\s+table/i,
  /insert\s+into/i,
  /--/i,
  /\balert\s*\(/i,
  /\bselect\b.*\bfrom\b/i,
  /base64,[A-Za-z0-9+/=]+/i,
  /curl\s+http/i,
  /wget\s+http/i,
  /(\/etc\/passwd)/i
];

// Helpers: storage wrappers
async function getStorage(key, defaultVal) {
  const r = await browser.storage.local.get(key);
  return r[key] !== undefined ? r[key] : defaultVal;
}

async function setStorage(key, value) {
  await browser.storage.local.set({ [key]: value });
}

// Logging
async function pushLog(entry) {
  const logs = await getStorage(STORAGE_KEYS.LOGS, []);
  logs.unshift(entry);
  if (logs.length > MAX_LOGS) logs.splice(MAX_LOGS);
  await setStorage(STORAGE_KEYS.LOGS, logs);
  // notify dashboard if open
  try { browser.runtime.sendMessage({ type: "waf_new_log", entry }); } catch (e) {}
}

// Mode helpers
async function getMode() {
  return await getStorage(STORAGE_KEYS.MODE, "non-blocking");
}
async function setMode(mode) {
  await setStorage(STORAGE_KEYS.MODE, mode);
}

// Whitelist helpers
async function getWhitelist() {
  return await getStorage(STORAGE_KEYS.WHITELIST, DEFAULT_WHITELIST.slice());
}
async function addToWhitelist(domain) {
  const wl = await getWhitelist();
  if (!wl.includes(domain)) wl.push(domain);
  await setStorage(STORAGE_KEYS.WHITELIST, wl);
  return wl;
}
async function removeFromWhitelist(domain) {
  let wl = await getWhitelist();
  wl = wl.filter(d => d !== domain);
  await setStorage(STORAGE_KEYS.WHITELIST, wl);
  return wl;
}

// Detection
function matchKeyword(data) {
  const low = data.toLowerCase();
  for (const k of suspiciousKeywords) {
    if (low.includes(k)) return { type: "keyword", match: k };
  }
  for (const rx of suspiciousPatterns) {
    if (rx.test(data)) return { type: "pattern", match: rx.toString() };
  }
  return false;
}

// Main request listener
browser.webRequest.onBeforeRequest.addListener(
  async function(details) {
    try {
      const url = details.url || "";
      const body = (details.requestBody && details.requestBody.raw && details.requestBody.raw[0])
        ? new TextDecoder().decode(details.requestBody.raw[0].bytes || new Uint8Array())
        : "";
      const data = url + " " + body;
      const detected = matchKeyword(data);
      if (!detected) return; // nothing suspicious

      // If suspicious detected, log and maybe block based on mode
      const mode = await getMode();
      const entry = { ts: Date.now(), url: url, method: details.method, detected: detected, mode: mode };
      await pushLog(entry);

      if (mode === "blocking") {
        console.warn("[WAF] Blocking request:", url, detected);
        try {
          browser.notifications.create({
            type: "basic",
            iconUrl: "icons/icon48.png",
            title: "WAF Blocked Request",
            message: `${detected.type}: ${detected.match}\n${url}`
          });
        } catch (e) {}
        return { cancel: true };
      } else {
        // non-blocking: just notify / log
        try {
          browser.notifications.create({
            type: "basic",
            iconUrl: "icons/icon48.png",
            title: "WAF Detected",
            message: `${detected.type}: ${detected.match}\n${url}`
          });
        } catch (e) {}
        return;
      }
    } catch (e) {
      console.error("[WAF] Error in onBeforeRequest:", e);
    }
  },
  { urls: ["http://*/*", "https://*/*"] },
  ["blocking", "requestBody"]
);

// Message API for dashboard
browser.runtime.onMessage.addListener(async (msg) => {
  if (msg && msg.type === "waf_get_state") {
    const mode = await getMode();
    const logs = await getStorage(STORAGE_KEYS.LOGS, []);
    const wl = await getWhitelist();
    return { mode, logs, whitelist: wl };
  } else if (msg && msg.type === "waf_set_mode") {
    await setMode(msg.mode);
    return { ok: true };
  } else if (msg && msg.type === "waf_add_whitelist") {
    const wl = await addToWhitelist(msg.domain);
    return { ok: true, whitelist: wl };
  } else if (msg && msg.type === "waf_remove_whitelist") {
    const wl = await removeFromWhitelist(msg.domain);
    return { ok: true, whitelist: wl };
  } else if (msg && msg.type === "waf_clear_logs") {
    await setStorage(STORAGE_KEYS.LOGS, []);
    return { ok: true };
  }
});
