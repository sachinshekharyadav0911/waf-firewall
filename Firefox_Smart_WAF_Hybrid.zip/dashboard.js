async function fetchState() {
  return await browser.runtime.sendMessage({ type: "waf_get_state" });
}

function renderLogs(logs) {
  const container = document.getElementById("logsContainer");
  if (!logs || logs.length === 0) {
    container.innerHTML = "<div class='empty'>No events detected yet.</div>";
    return;
  }
  let html = "<table class='logtable'><tr><th>Time</th><th>URL</th><th>Detected</th><th>Mode</th></tr>";
  for (const e of logs) {
    const time = new Date(e.ts).toLocaleString();
    html += `<tr><td>${time}</td><td class='urlcell'>${e.url}</td><td>${e.detected.type}: ${e.detected.match}</td><td>${e.mode}</td></tr>`;
  }
  html += "</table>";
  container.innerHTML = html;
}

function renderWhitelist(wl) {
  const ul = document.getElementById("wlList");
  ul.innerHTML = "";
  for (const d of wl) {
    const li = document.createElement("li");
    li.textContent = d;
    const btn = document.createElement("button");
    btn.textContent = "Remove";
    btn.onclick = async () => {
      await browser.runtime.sendMessage({ type: "waf_remove_whitelist", domain: d });
      load();
    };
    li.appendChild(btn);
    ul.appendChild(li);
  }
}

async function load() {
  const state = await fetchState();
  document.getElementById("modeIndicator").textContent = `Mode: ${state.mode}`;
  renderLogs(state.logs);
  renderWhitelist(state.whitelist);
}

document.getElementById("toggleMode").onclick = async () => {
  const state = await fetchState();
  const newMode = state.mode === "blocking" ? "non-blocking" : "blocking";
  await browser.runtime.sendMessage({ type: "waf_set_mode", mode: newMode });
  load();
};

document.getElementById("addWl").onclick = async () => {
  const domain = document.getElementById("wlInput").value.trim();
  if (!domain) return;
  await browser.runtime.sendMessage({ type: "waf_add_whitelist", domain });
  document.getElementById("wlInput").value = "";
  load();
};

document.getElementById("clearLogs").onclick = async () => {
  await browser.runtime.sendMessage({ type: "waf_clear_logs" });
  load();
};

// Live update when new log comes
browser.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "waf_new_log") {
    load();
  }
});

load();
